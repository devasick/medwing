import React, { Component, createRef } from 'react'
import { Map, GoogleApiWrapper, Marker } from 'google-maps-react';


 
export class MapContainer extends Component {
    
    constructor(props) {
      super(props);
      this.state = {
        error: null,
        isLoaded: true,
        stores: []
      };
      
       
    }

    fetchMap() {
        // Where we're fetching data from
        return(
        fetch("http://asickweb.com/react/api/?marker_data=data")
          .then(res => res.json())
          
          .then(
            (result) => {
              this.setState({
                isLoaded: true,
                stores: result
              });
              
               
            },
             
            // Note: it's important to handle errors here
            // instead of a catch() block so that we don't swallow
            // exceptions from actual bugs in components.
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
          
        ) // return

        
      }

      async componentDidMount() {

        var GoogleMap = this.fetchMap();
        var markerfun = this.displayMarkers();

      }
  
 

    displayMarkers = () => {
       //var test = this.state.items
       //this.setState({stores: this.state.items});

       //console.log(this.state.stores)
        return this.state.stores.map((store, index) => {
          return <Marker key={index} id={index} position={{
           lat: store.googlelat,
           lng: store.googlellng
         }}
         onClick={() => console.log("You clicked me!")} />
        })
      }
    

    
    
  
    render() {
        
        
        const mapStyles = {
            width: '100%',
            height: '600px',
          }; 
      return (
         
          <Map
            google={this.props.google}
            zoom={5}
            style={mapStyles}
            initialCenter={{ lat: 51.1657, lng: 10.4515}}
          >
            {this.displayMarkers()}
          </Map>
      );
    }
  }

  export default GoogleApiWrapper({
    apiKey: 'AIzaSyDRCcfJVtzzqsrmB5NpU2pytpTEjNlUDUk&libraries'
  })(MapContainer);
