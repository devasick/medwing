import React, { Component } from 'react'
import axios from 'axios';
export default class Deletemap extends Component {

    constructor(props) {
		super(props);
    }
    componentDidMount() {
    axios.get('hhttp://asickweb.com/react/api/?delete='+this.props.match.params.id)
            .then(response => {
                this.setState({ 
                });
                this.props.history.push('/');
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            })
      }
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

 
