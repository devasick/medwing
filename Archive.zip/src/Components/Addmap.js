import React, { Component } from 'react'
import { Button,Form,Col } from 'react-bootstrap';
import Autocomplete from "./Autocomplete";
import axios from 'axios';
const API_PATH = 'http://localhost/api/';
const google = window.google;
 


 

export default class Addmap extends Component {
    constructor(props) {
        super(props)
        this.state = this.initialState()
        this.handlePlaceSelect = this.handlePlaceSelect.bind(this)
        this.handleChange = this.handleChange.bind(this)
        this.handleSubmit = this.handleSubmit.bind(this)
        this.autocomplete = null
      }
    
      componentDidMount() {
        var options = {
            //types: ['(cities)'],
            componentRestrictions: {country: "de"}
           };
    
        this.autocomplete = new google.maps.places.Autocomplete(document.getElementById('autocomplete'),options ,{types: ["establishment"]})
    
        this.autocomplete.addListener("place_changed", this.handlePlaceSelect)
      }
    
      initialState() {
        return {
          name: '',
          id:'', 
          googlelat:'',
          googlellng:'',
        
        }
      }
    
      handleChange(event) {
        this.setState({[event.target.name]: event.target.value})
      }
    
      handleSubmit(event) {
        event.preventDefault()
        console.log(this.state);
        const { history } = this.props;

        //this.props.dispatch(this.state)
        var headersvar = {
            'Access-Control-Allow-Origin': '*',        
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
    

        axios({
            method: 'post',
            url: 'http://asickweb.com/react/api/?add=data',
            data: this.state,
            config: { headers:headersvar}
        })
        .then(function (response) {
 
            history.push('/');

             console.log(response)

        })
        .catch(function (response) {
            //handle error
            console.log(response)
        });
      }
    
      handlePlaceSelect() {
        let addressObject = this.autocomplete.getPlace();
        var lat = addressObject.geometry.location.lat(),
        lng = addressObject.geometry.location.lng();
        let address = addressObject.address_components
        console.log(addressObject)
         
       
        this.setState({
          name: addressObject.name,
          id: addressObject.id,
          googlelat: lat,
          googlellng: lng,
           
           
        })
      }
    
    

    state = {
        place: {},
        };
    
    
      showPlaceDetails(place) {
        this.setState({ place });
      }


      /*handleFormSubmit = e => {
        e.preventDefault();
            this.props.dispatch(addParlor(this.state))

        axios({
          method: 'post',
          url: `${API_PATH}`,
          headers: { 'content-type': 'application/json' },
          data: this.state
        })
          .then(result => {
            this.setState({
              mailSent: result.data.sent
            })
          })
          .catch(error => this.setState({ error: error.message }));
      }; */
      
     

    render() {
        const AddressDetails = props => {
 
            return (
                 <div>
                  <pre>{JSON.stringify(props.place, null, 2)}</pre>
                 </div>
            )
          };


        return (
            <Col sm={12} md={12}>
                <h5 className="text-uppercase">Add Map Location</h5>
                <form onSubmit={this.handleSubmit}>
                <Form.Group>
             <Form.Control type="text" placeholder="Enter Address" id="autocomplete" ref="input"/>
                 <Form.Text className="text-muted">
                 Google Map autocomplete will appear
                </Form.Text>
            </Form.Group>

            <Form.Group>
             <Form.Control type="text" placeholder="Location Name" readOnly name={"name"} value={this.state.name}
               onChange={this.handleChange}/>
            </Form.Group>
            <Form.Group>
             <Form.Control type="text" placeholder="Latitude" readOnly name={"lat"} value={this.state.googlelat}
               onChange={this.handleChange}/>
            </Form.Group>
            <Form.Group>
             <Form.Control type="text" readOnly placeholder="Longitude" name={"lng"} value={this.state.googlellng}
               onChange={this.handleChange}/>
            </Form.Group>
           
            
          
            <button onSubmit={this.handleSubmit} className="button">Submit</button>
        </form>

            </Col>
        )
    }
}

 