import React, { Component } from 'react'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import { Button,Form } from 'react-bootstrap';


export default class Listmap extends Component {
    constructor(props) {
        super(props);
        this.state = {
          error: null,
          isLoaded: false,
          items: []
        };
      }

      
    
      componentDidMount() {
        fetch("http://asickweb.com/react/api/?fetch=data")
          .then(res => res.json())
          .then(
            (result) => {
              this.setState({
                isLoaded: true,
                items: result
              });
            },
            // Note: it's important to handle errors here
            // instead of a catch() block so that we don't swallow
            // exceptions from actual bugs in components.
            (error) => {
              this.setState({
                isLoaded: true,
                error
              });
            }
          )
      }

    render() {
        const { error, isLoaded, items } = this.state;
       // console.log(items)
        return (
            <div>
             <Link to="/add"> 
             <Button variant="primary">Add Map</Button>
            </Link>
            <hr></hr>
            {items.map(function (item, i) { 
			    return <div key={i} className="d-inline-block w-50">
				<h5>{item.location_name}</h5>
				<p>Latitude: {item.googlelat}</p>
                <p>Longitude: {item.googlellng}</p>
                <span><Link to={"/edit/"+item.m_id} className="btn">Edit</Link></span>
                <span className="ml-2 text-red"><Link to={"/delete/"+item.m_id} className="btn">Delete</Link></span>
 				</div>
			  })}


            </div>
        )
    }
}
