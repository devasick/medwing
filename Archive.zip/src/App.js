import React,{Component}  from 'react';
import logo from './logo.svg';
import './App.css';
import GoogleMapReact from 'google-map-react';
import { Button,Container,Col,Row } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom'; 

import Listmap from './Components/Listmap';  
import Addmap from './Components/Addmap'; 
import Editmap from './Components/Editmap';
import Deletemap from './Components/Deletemap';
import GoogleMap from './Components/GoogleMap';

const AnyReactComponent = ({ text }) => <div>{text}</div>;


class MedWing extends Component {
 
  render() {
    return (
      
     <React.Fragment>
    <Container>
    <Row>
      <Col sm={12} md={6}>
              {/* Map   */}
      <GoogleMap/>
      </Col>
      <Col sm={12} md={6}>
      {/* Router  */}
        <Router basename='/demo/'>
          <Switch>
            <Route exact path="/" component={Listmap} />
            <Route path="/add" component={Addmap} />
            <Route path="/edit/:id" component={Editmap} />
            <Route path="/delete/:id" component={Deletemap} />
          </Switch>
      </Router>
      {/* Router  */}
    </Col>
    </Row>
   
    </Container>
    </React.Fragment>
    );
  }
}
 
export default MedWing;
